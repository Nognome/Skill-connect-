var Switch = document.querySelector(".checkbox").onclick = toggleNav;
	var mainHeader = document.querySelector(".relative.header");
	var header = document.querySelector(".alt-header");
	var sidebar = document.querySelector(".sidebar");
	var sidebarSwitch = document.querySelector(".sidebarSwitch").onclick = toggleSidebar;
	var sidebarSwitchR = document.querySelector(".sidebarSwitch");

	function toggleNav(){
		if (this.checked == true) {
			header.style.visibility = "visible";
			header.style.opacity = "1";
			header.style.transform = "scale(1)";
		}
		else{
			header.style.visibility = "hidden";
			header.style.transform = "scale(0)";
			header.style.opacity = "0";
		}
	};

	function fixHeader(){
		if (pageYOffset > 221) {
			mainHeader.style.position = "fixed";
			mainHeader.style.top = "-1px";
			mainHeader.style.padding = "6px";
			header.style.marginLeft = "-7px"
		}else{
			mainHeader.style.position = "relative";
			mainHeader.style.padding = "10px";
			mainHeader.style.top = "0px";
			header.style.marginLeft = " ";
		}
	};
	function toggleSidebar(){
		if (this.checked == true) {
			sidebar.style.left = "0px";
		}
		else{
			sidebar.style.left = " -1000px";
		}
	}
